<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>GAIL Info.</title>
        <style>

  body{
    width: 100%;
    height: 100vh;
    background: #0f8a9d;
    background: linear-gradient(57deg, #00C6A7 , #1E4D92 ); 
    
  }
  .container
{
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 100%;
}
.container span
{
    text-transform: uppercase;
    display: block;
}
.middle {
  transition: .5s ease;
  opacity: 0;
  position: fixed;
  top: 50%;
  left: 45%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}
.image{
  margin-top: -25px;
  border-radius: 50%;
  height: 250px;
  width: 250px;
}


.text1
{
    color: gold;
    font-size: 50px;
    font-weight: 300;
    letter-spacing: 3px;
    margin-bottom: 20px;
    position: relative;
    animation: text 3s 1;
}
.text2
{
    color: #780150;
    font-size: 40px;
    margin-left: 70px;
    margin-right: 70px;
}
@keyframes text
{
    0%
    {
        color: #015282;
        margin-bottom: -40%;
    }
    30%
    {
        margin-bottom: 25%;
        margin-bottom: -40%;
    }
    85%
    {
        letter-spacing: 4px;
        margin-bottom: -40%;

    }
}
.button a{
  position: relative;
  text-align: center;
  width: 80px;
  padding: 10px;
  font-size: 25px;
  font-family: cursive;
  font-weight: 450;
  border: 3px solid #15f4ee;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  border-radius: 100px;
  transition: 1.5s;
  text-decoration: none;
  color: #000;
}
.button a:hover{
  box-shadow: 0 5px 50px 0 #15f4ee inset, 0 5px 50px 0 #15f4ee,
  0 5px 50px 0 #15f4ee inset, 0 5px 50px 0 #15f4ee;
  text-shadow: 0 0 5px #15f4ee,0 0 5px #15f4ee,;
}

</style>
</head>
<body>
<div class="container">
  <img src="gail.png"  class="image">

     <span class="text1"> Gail India Limited </span>
     <span class="text2"> Government of India undertaking company .</span>
        <br>
        <br>
        
        <div class="button"><a href="login.php">Login</a></div>
</div>
<br>

  
    </body>