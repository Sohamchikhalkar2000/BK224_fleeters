<!DOCTYPE html>
<html>
    <head>
        <title>User Login & Registration</title>
        <link rel="stylesheet" type="text/css" href="style2.css">
       
         <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    </head>
    
<body>


 <div class="hero">
     <div class="form-box">
        <div class="button-box">
            <div id="btn"></div>
            <button type="button" class="toggle-btn" onclick="login()">Log In</button>
            <button type="button" class="toggle-btn" onclick="register()">Register</button>

        </div>
    
    <form id="login" class="input-group" action="validation.php" method="POST">
        <input type="text" name="user" class="input-field" placeholder="User Id" required>
        <input type="password" name="password" class="input-field" placeholder="Enter Password" required>
        <input type="checkbox" class="check-box"><span>Remember Password</span>
        <button type="submit" class="submit-btn">Log In</button>
    </form>

    <form id="register" class="input-group" action="registration.php" method="POST">
        <input type="text" name="user" class="input-field" placeholder="User Id" required>
        <input type="password" name="password" class="input-field" placeholder="Enter Password" required>
        <input type="checkbox" class="check-box"><span>Remember Password</span>
        <button type="submit" name="signup" class="submit-btn" value="signup" onclick="popUp()" id="pop">Register</button>
    </form>

    </div>
</div>

    <script>
        var x = document.getElementById("login");
        var y = document.getElementById("register");
        var z = document.getElementById("btn");

        function register(){
            x.style.left = "-400px";
            y.style.left = "50px";
            z.style.left = "110px";
        }

        function login(){
            x.style.left = "50px";
            y.style.left = "450px";
            z.style.left = "0px";
        }
         
        function popUp(){
            swal("Registration Successfully!", "success");
        }

    </script>


</body>
</html>


